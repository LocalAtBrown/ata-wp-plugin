window.onload = function() {

var element = document.querySelector(".newsletter-disabled");
  console.log("Is the newsletter pop-up disabled?");
if (element) {
  console.log("Yes. You should NOT see the newsletter pop up anymore.");
} else {
  console.log("No. You should still see it on every page.");
}
};
